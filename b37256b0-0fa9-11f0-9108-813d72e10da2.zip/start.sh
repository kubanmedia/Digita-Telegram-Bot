#!/bin/bash
# Start the bot
python bot.py
