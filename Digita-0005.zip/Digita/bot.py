
import os
import telebot
from gtts import gTTS
from groq import Groq
from collections import defaultdict
import re
import langid
from telebot.types import InlineKeyboardMarkup, InlineKeyboardButton

# Получаем токен бота из переменных окружения
TOKEN = os.getenv("TELEGRAM_BOT_TOKEN")
if not TOKEN:
    print("No token provided. Set the TELEGRAM_BOT_TOKEN environment variable.")
    exit(1)

# Получаем API ключ Groq из переменных окружения
GROQ_API_KEY = os.getenv("GROQ_API_KEY")
if not GROQ_API_KEY:
    print("No Groq API key provided. Set the GROQ_API_KEY environment variable.")
    exit(1)

# Инициализация Groq клиента
client = Groq(api_key=GROQ_API_KEY)

# Инициализация бота
bot = telebot.TeleBot(TOKEN)

# Словарь для хранения истории сообщений по пользователям
conversation_history = defaultdict(list)
# Максимальное количество сообщений в истории для одного пользователя
MAX_HISTORY = 10

# Словарь для хранения настроек пользователей
user_settings = defaultdict(lambda: {
    'model': 'llama3-8b-8192',
    'temperature': 0.7,
    'max_tokens': 1000,
    'language': 'auto',
    'personality': 'default'
})

# Доступные языки для синтеза речи (код : имя)
AVAILABLE_LANGUAGES = {
    'auto': 'Автоопределение',
    'ru': 'Русский',
    'en': 'English',
    'fr': 'Français',
    'de': 'Deutsch',
    'es': 'Español',
    'it': 'Italiano',
    'ja': '日本語',
    'zh': '中文'
}

# Доступные модели Groq API
AVAILABLE_MODELS = {
    'llama3-8b-8192': 'Llama 3 (8B) - Быстрая',
    'llama3-70b-8192': 'Llama 3 (70B) - Мощная',
    'gemma-7b-it': 'Gemma (7B) - Универсальная'
}

# Шаблоны для разных личностей бота
PERSONALITIES = {
    'default': 'Ты дружелюбный ассистент, который помогает пользователям с их вопросами. Ты отвечаешь на языке пользователя.',
    'scientist': 'Ты научный ассистент с аналитическим складом ума. Ты предпочитаешь точные факты, ссылки на исследования и научный подход к решению проблем.',
    'creative': 'Ты творческий ассистент с богатым воображением. Ты любишь предлагать нестандартные идеи, метафоры и вдохновляющие рассуждения.',
    'business': 'Ты деловой консультант. Ты говоришь лаконично, конкретно и всегда ориентирован на результат и эффективность.',
    'philosopher': 'Ты философ и мыслитель. Ты любишь глубокие рассуждения, задаешь вопросы и рассматриваешь проблемы с разных сторон, приводя исторические и философские контексты.'
}

# Определение языка текста
def detect_language(text):
    # Сначала проверяем наличие кириллицы для русского языка (более точно)
    if re.search('[а-яА-ЯёЁ]', text):
        return 'ru'
    
    # Используем langid для других языков
    lang, _ = langid.classify(text)
    
    # Проверяем, поддерживается ли определенный язык
    if lang in AVAILABLE_LANGUAGES:
        return lang
    else:
        return 'en'  # Английский как язык по умолчанию

# Функция для отправки голосового сообщения
def send_voice_message(chat_id, text, lang='auto'):
    try:
        # Если указано автоопределение языка, определяем язык
        if lang == 'auto':
            lang = detect_language(text)
            
        # Если язык не поддерживается gTTS, используем английский
        if lang not in ['ru', 'en', 'fr', 'de', 'es', 'it', 'ja', 'zh']:
            lang = 'en'
            
        # Создаем аудиофайл
        tts = gTTS(text=text, lang=lang, slow=False)
        temp_file = f"voice_message_{chat_id}.mp3"
        tts.save(temp_file)
        
        # Отправляем голосовое сообщение
        with open(temp_file, 'rb') as audio:
            bot.send_voice(chat_id, audio)
        
        # Удаляем временный файл
        os.remove(temp_file)
    except Exception as e:
        bot.send_message(chat_id, f"Ошибка при создании голосового сообщения: {str(e)}")

# Создание клавиатуры с настройками
def create_settings_keyboard():
    markup = InlineKeyboardMarkup(row_width=2)
    markup.add(
        InlineKeyboardButton("🤖 Модель", callback_data="set_model"),
        InlineKeyboardButton("🔥 Температура", callback_data="set_temperature"),
        InlineKeyboardButton("📏 Длина ответа", callback_data="set_max_tokens"),
        InlineKeyboardButton("🌐 Язык", callback_data="set_language"),
        InlineKeyboardButton("👤 Личность", callback_data="set_personality")
    )
    return markup

# Создание клавиатуры для выбора моделей
def create_models_keyboard():
    markup = InlineKeyboardMarkup(row_width=1)
    for model_id, model_name in AVAILABLE_MODELS.items():
        markup.add(InlineKeyboardButton(model_name, callback_data=f"model_{model_id}"))
    markup.add(InlineKeyboardButton("↩️ Назад", callback_data="back_to_settings"))
    return markup

# Создание клавиатуры для выбора температуры
def create_temperature_keyboard():
    markup = InlineKeyboardMarkup(row_width=3)
    temperatures = [("0.2 (Точно)", "temp_0.2"), ("0.5 (Сбалансированно)", "temp_0.5"), 
                   ("0.7 (По умолчанию)", "temp_0.7"), ("0.9 (Креативно)", "temp_0.9"), 
                   ("1.0 (Максимально креативно)", "temp_1.0")]
    for temp_name, callback in temperatures:
        markup.add(InlineKeyboardButton(temp_name, callback_data=callback))
    markup.add(InlineKeyboardButton("↩️ Назад", callback_data="back_to_settings"))
    return markup

# Создание клавиатуры для выбора длины ответа
def create_max_tokens_keyboard():
    markup = InlineKeyboardMarkup(row_width=3)
    token_options = [("Короткий (500)", "tokens_500"), ("Средний (1000)", "tokens_1000"), 
                     ("Длинный (2000)", "tokens_2000"), ("Очень длинный (4000)", "tokens_4000")]
    for token_name, callback in token_options:
        markup.add(InlineKeyboardButton(token_name, callback_data=callback))
    markup.add(InlineKeyboardButton("↩️ Назад", callback_data="back_to_settings"))
    return markup

# Создание клавиатуры для выбора языка
def create_language_keyboard():
    markup = InlineKeyboardMarkup(row_width=2)
    for lang_code, lang_name in AVAILABLE_LANGUAGES.items():
        markup.add(InlineKeyboardButton(lang_name, callback_data=f"lang_{lang_code}"))
    markup.add(InlineKeyboardButton("↩️ Назад", callback_data="back_to_settings"))
    return markup

# Создание клавиатуры для выбора личности
def create_personality_keyboard():
    markup = InlineKeyboardMarkup(row_width=1)
    personalities = {
        'default': 'Обычный ассистент',
        'scientist': 'Научный эксперт',
        'creative': 'Творческая личность',
        'business': 'Бизнес-консультант',
        'philosopher': 'Философ'
    }
    for personality_id, personality_name in personalities.items():
        markup.add(InlineKeyboardButton(personality_name, callback_data=f"personality_{personality_id}"))
    markup.add(InlineKeyboardButton("↩️ Назад", callback_data="back_to_settings"))
    return markup

# Обработчик команды /start
@bot.message_handler(commands=['start'])
def send_welcome(message):
    # Очищаем историю сообщений при старте нового диалога
    user_id = message.from_user.id
    conversation_history[user_id] = []
    
    text = "👋 Привет! Я бот с Groq API и моделью Llama 3. Используй /help для списка команд или просто пиши мне! Я помню наш разговор для лучшего контекста."
    bot.reply_to(message, text)
    # Озвучиваем приветствие
    send_voice_message(message.chat.id, text, user_settings[user_id]['language'])

# Обработчик команды /help
@bot.message_handler(commands=['help'])
def send_help(message):
    text = """📋 Доступные команды:
/start - Начать работу и очистить историю диалога
/help - Показать это сообщение
/clear - Очистить историю сообщений
/settings - Настройки бота (модель, температура, язык и т.д.)
/info - Информация о текущих настройках

Любой текст - получить ответ от AI, который я также озвучу"""
    bot.reply_to(message, text)
    # Озвучиваем помощь
    send_voice_message(message.chat.id, text, user_settings[message.from_user.id]['language'])

# Обработчик команды /clear
@bot.message_handler(commands=['clear'])
def clear_history(message):
    user_id = message.from_user.id
    conversation_history[user_id] = []
    text = "🧹 История сообщений очищена. Начинаем диалог с чистого листа!"
    bot.reply_to(message, text)
    send_voice_message(message.chat.id, text, user_settings[user_id]['language'])

# Обработчик команды /settings
@bot.message_handler(commands=['settings'])
def settings_command(message):
    user_id = message.from_user.id
    markup = create_settings_keyboard()
    bot.send_message(chat_id=message.chat.id, 
                     text="⚙️ Настройки бота. Выберите, что хотите изменить:",
                     reply_markup=markup)

# Обработчик команды /info
@bot.message_handler(commands=['info'])
def info_command(message):
    user_id = message.from_user.id
    settings = user_settings[user_id]
    
    # Получаем названия текущих настроек
    model_name = AVAILABLE_MODELS.get(settings['model'], settings['model'])
    language_name = AVAILABLE_LANGUAGES.get(settings['language'], settings['language'])
    personality_names = {
        'default': 'Обычный ассистент',
        'scientist': 'Научный эксперт',
        'creative': 'Творческая личность',
        'business': 'Бизнес-консультант',
        'philosopher': 'Философ'
    }
    personality_name = personality_names.get(settings['personality'], settings['personality'])
    
    info_text = f"""ℹ️ Текущие настройки:

🤖 Модель: {model_name}
🔥 Температура: {settings['temperature']}
📏 Длина ответа: {settings['max_tokens']} токенов
🌐 Язык голоса: {language_name}
👤 Личность: {personality_name}

Для изменения настроек используйте команду /settings"""
    
    bot.send_message(message.chat.id, info_text)

# Обработчик нажатий на inline кнопки
@bot.callback_query_handler(func=lambda call: True)
def handle_query(call):
    user_id = call.from_user.id
    
    # Обработка выбора категории настроек
    if call.data == "set_model":
        markup = create_models_keyboard()
        bot.edit_message_text(chat_id=call.message.chat.id, 
                             message_id=call.message.message_id,
                             text="🤖 Выберите модель AI:",
                             reply_markup=markup)
                             
    elif call.data == "set_temperature":
        markup = create_temperature_keyboard()
        bot.edit_message_text(chat_id=call.message.chat.id, 
                             message_id=call.message.message_id,
                             text="🔥 Выберите температуру генерации:\n\nЧем выше температура, тем более разнообразные и творческие ответы. Чем ниже - тем более предсказуемые и точные.",
                             reply_markup=markup)
                             
    elif call.data == "set_max_tokens":
        markup = create_max_tokens_keyboard()
        bot.edit_message_text(chat_id=call.message.chat.id, 
                             message_id=call.message.message_id,
                             text="📏 Выберите максимальную длину ответа:",
                             reply_markup=markup)
                             
    elif call.data == "set_language":
        markup = create_language_keyboard()
        bot.edit_message_text(chat_id=call.message.chat.id, 
                             message_id=call.message.message_id,
                             text="🌐 Выберите язык для голосовых сообщений:",
                             reply_markup=markup)
                             
    elif call.data == "set_personality":
        markup = create_personality_keyboard()
        bot.edit_message_text(chat_id=call.message.chat.id, 
                             message_id=call.message.message_id,
                             text="👤 Выберите личность бота:",
                             reply_markup=markup)
    
    # Возврат к общему меню настроек
    elif call.data == "back_to_settings":
        markup = create_settings_keyboard()
        bot.edit_message_text(chat_id=call.message.chat.id, 
                             message_id=call.message.message_id,
                             text="⚙️ Настройки бота. Выберите, что хотите изменить:",
                             reply_markup=markup)
    
    # Обработка выбора модели
    elif call.data.startswith("model_"):
        selected_model = call.data.split("_", 1)[1]
        user_settings[user_id]['model'] = selected_model
        model_name = AVAILABLE_MODELS.get(selected_model, selected_model)
        
        markup = create_settings_keyboard()
        bot.edit_message_text(chat_id=call.message.chat.id, 
                             message_id=call.message.message_id,
                             text=f"✅ Модель изменена на {model_name}.\n\n⚙️ Настройки бота. Выберите, что хотите изменить:",
                             reply_markup=markup)
    
    # Обработка выбора температуры
    elif call.data.startswith("temp_"):
        selected_temp = float(call.data.split("_")[1])
        user_settings[user_id]['temperature'] = selected_temp
        
        markup = create_settings_keyboard()
        bot.edit_message_text(chat_id=call.message.chat.id, 
                             message_id=call.message.message_id,
                             text=f"✅ Температура изменена на {selected_temp}.\n\n⚙️ Настройки бота. Выберите, что хотите изменить:",
                             reply_markup=markup)
    
    # Обработка выбора максимального количества токенов
    elif call.data.startswith("tokens_"):
        selected_tokens = int(call.data.split("_")[1])
        user_settings[user_id]['max_tokens'] = selected_tokens
        
        markup = create_settings_keyboard()
        bot.edit_message_text(chat_id=call.message.chat.id, 
                             message_id=call.message.message_id,
                             text=f"✅ Длина ответа изменена на {selected_tokens} токенов.\n\n⚙️ Настройки бота. Выберите, что хотите изменить:",
                             reply_markup=markup)
    
    # Обработка выбора языка
    elif call.data.startswith("lang_"):
        selected_lang = call.data.split("_")[1]
        user_settings[user_id]['language'] = selected_lang
        lang_name = AVAILABLE_LANGUAGES.get(selected_lang, selected_lang)
        
        markup = create_settings_keyboard()
        bot.edit_message_text(chat_id=call.message.chat.id, 
                             message_id=call.message.message_id,
                             text=f"✅ Язык изменен на {lang_name}.\n\n⚙️ Настройки бота. Выберите, что хотите изменить:",
                             reply_markup=markup)
    
    # Обработка выбора личности
    elif call.data.startswith("personality_"):
        selected_personality = call.data.split("_", 1)[1]
        user_settings[user_id]['personality'] = selected_personality
        
        personality_names = {
            'default': 'Обычный ассистент',
            'scientist': 'Научный эксперт',
            'creative': 'Творческая личность',
            'business': 'Бизнес-консультант',
            'philosopher': 'Философ'
        }
        personality_name = personality_names.get(selected_personality, selected_personality)
        
        markup = create_settings_keyboard()
        bot.edit_message_text(chat_id=call.message.chat.id, 
                             message_id=call.message.message_id,
                             text=f"✅ Личность изменена на {personality_name}.\n\n⚙️ Настройки бота. Выберите, что хотите изменить:",
                             reply_markup=markup)
    
    # Завершаем запрос в любом случае
    bot.answer_callback_query(call.id)

# Обработчик текстовых сообщений
@bot.message_handler(content_types=['text'])
def handle_text(message):
    # Проверяем, что это не команда
    if message.text.startswith('/'):
        return
    
    user_id = message.from_user.id
    settings = user_settings[user_id]
    
    try:
        # Добавляем сообщение пользователя в историю
        conversation_history[user_id].append({"role": "user", "content": message.text})
        
        # Ограничиваем историю максимальным количеством сообщений
        if len(conversation_history[user_id]) > MAX_HISTORY:
            conversation_history[user_id] = conversation_history[user_id][-MAX_HISTORY:]
        
        # Определяем язык сообщения пользователя для системной подсказки
        user_lang = detect_language(message.text)
        
        # Добавляем системное сообщение в зависимости от выбранной личности
        personality_prompt = PERSONALITIES[settings['personality']]
        
        # Если определен конкретный язык пользователя и это не автоопределение,
        # добавляем подсказку для ответа на этом языке
        lang_hint = ""
        if settings['language'] != 'auto' and settings['language'] in AVAILABLE_LANGUAGES:
            lang_name = AVAILABLE_LANGUAGES[settings['language']]
            lang_hint = f" Отвечай на {lang_name}."
        
        system_message = {"role": "system", "content": personality_prompt + lang_hint}
        
        messages = [system_message]
        messages.extend(conversation_history[user_id])
        
        # Отправка индикатора набора текста
        bot.send_chat_action(message.chat.id, 'typing')
        
        # Отправляем запрос к Groq API с историей сообщений
        response = client.chat.completions.create(
            model=settings['model'],
            messages=messages,
            max_tokens=settings['max_tokens'],
            temperature=settings['temperature']
        )
        
        # Получаем текст ответа от Groq
        reply_text = response.choices[0].message.content
        
        # Добавляем ответ ассистента в историю
        conversation_history[user_id].append({"role": "assistant", "content": reply_text})
        
        # Отправляем текстовый ответ
        bot.reply_to(message, reply_text)
        
        # Определяем язык для голосового ответа
        voice_lang = settings['language']
        if voice_lang == 'auto':
            voice_lang = detect_language(reply_text)
        
        # Отправляем голосовой ответ
        send_voice_message(message.chat.id, reply_text, voice_lang)
        
    except Exception as e:
        error_message = f"Произошла ошибка: {str(e)}"
        bot.reply_to(message, error_message)
        send_voice_message(message.chat.id, error_message, 'ru')

# Запускаем бота
if __name__ == '__main__':
    print('Бот запущен...')
    # Устанавливаем langid для поддержки определения языков
    langid.set_languages(['ru', 'en', 'fr', 'de', 'es', 'it', 'ja', 'zh'])
    bot.polling(none_stop=True)
